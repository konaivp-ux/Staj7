# cash

Bot created with [Orbbis](https://orbbis.app) — the Discord bot builder platform.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Edit `.env` and add your bot token:
```
TOKEN=your_bot_token_here
CLIENT_ID=your_client_id_here
```

3. Run the bot:
```bash
node index.js
```

## Commands

- `!ping` — Check bot latency


## Enabled Systems

- 👋 Welcome Message
- 🚪 Goodbye Message
- 🔰 Auto-Moderation
- 📋 Server Logs
- 🎭 Auto Role
- 🎰 Giveaway
- 📊 Polls
- 🎫 Support Tickets
- 🔨 Moderation
- 📌 Server Info

## Hosting

Upload the ZIP to [Discloud](https://discloud.app) for free 24/7 hosting.

---
Built with ❤️ using [Orbbis](https://orbbis.app)
