const { Client, GatewayIntentBits, Partials, REST, Routes, ActivityType, Events, EmbedBuilder, PermissionFlagsBits, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
require('dotenv').config();

const TOKEN = process.env.TOKEN || 'MTU0NTIyMTA2NzEzODc5NzU2OA.GkVoKD.CKgCyiDjVraZhoOMesOXhZL1Jup_AkiFHZfpNc';
const CLIENT_ID = process.env.CLIENT_ID || '1545221067138797568';
const PREFIX = '!';
const ACCENT = 8141549;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildModeration,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction]
});

const rest = new REST({ version: '10' }).setToken(TOKEN);
const warnings = new Map();
const spamTrack = new Map();
let ticketCount = 1;

function embed(data){ return new EmbedBuilder().setColor(ACCENT).setTimestamp(Date.now()).setFooter({ text: 'cash' }).setTitle(data.title||null).setDescription(data.desc||null); }
function replace(str, member){ return (str||'').replace(/\{user\}/g,`<@${member.id}>`).replace(/\{username\}/g,member.user?.username||member.username||'').replace(/\{server\}/g,member.guild?.name||'').replace(/\{membercount\}/g,String(member.guild?.memberCount||0)); }
async function findChannel(guild, name){ return guild.channels.cache.find(c=>c.name===name||c.id===name); }
async function findRole(guild, name){ return guild.roles.cache.find(r=>r.name===name||r.id===name); }

// ── READY ──
client.once(Events.ClientReady, async () => {
  console.log(`✅ cash online as ${client.user.username}`);
  client.user.setPresence({ status: 'online' });

  const slashCmds = [
    
    
    ,{ name: 'ping', description: 'Check bot latency' }
    ,{ name: 'serverinfo', description: 'Show server information' }
    ,{ name: 'userinfo', description: 'Show user info', options: [{ type: 6, name: 'user', description: 'The user', required: false }] }
    ,{ name: 'avatar', description: 'Show user avatar', options: [{ type: 6, name: 'user', description: 'The user', required: false }] }
    
    ,{ name: 'ban', description: 'Ban a member', options: [{ type: 6, name: 'user', description: 'User to ban', required: true },{ type: 3, name: 'reason', description: 'Reason', required: false }] }
    ,{ name: 'kick', description: 'Kick a member', options: [{ type: 6, name: 'user', description: 'User to kick', required: true },{ type: 3, name: 'reason', description: 'Reason', required: false }] }
    ,{ name: 'mute', description: 'Timeout a member', options: [{ type: 6, name: 'user', description: 'User to mute', required: true },{ type: 4, name: 'minutes', description: 'Duration in minutes', required: true },{ type: 3, name: 'reason', description: 'Reason', required: false }] }
    ,{ name: 'warn', description: 'Warn a member', options: [{ type: 6, name: 'user', description: 'User to warn', required: true },{ type: 3, name: 'reason', description: 'Reason', required: true }] }
    ,{ name: 'warnings', description: 'Show warnings of a member', options: [{ type: 6, name: 'user', description: 'The user', required: true }] }
    ,{ name: 'clearwarn', description: 'Clear warnings of a member', options: [{ type: 6, name: 'user', description: 'The user', required: true }] }
    ,{ name: 'purge', description: 'Delete messages', options: [{ type: 4, name: 'amount', description: 'Amount to delete', required: true }] }
    ,{ name: 'giveaway', description: 'Giveaway commands', options: [{ type: 1, name: 'start', description: 'Start a giveaway', options: [{ type: 3, name: 'prize', description: 'Prize', required: true },{ type: 4, name: 'minutes', description: 'Duration in minutes', required: false }] }] }
    ,{ name: 'poll', description: 'Create a poll', options: [{ type: 3, name: 'question', description: 'Poll question', required: true }] }
    ,{ name: 'tickets', description: 'Post the ticket panel (admin)', defaultMemberPermissions: '8' }
  ].filter(Boolean);

  try {
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: slashCmds });
    console.log(`✅ ${slashCmds.length} commands registered!`);
  } catch(e) { console.error('Commands error:', e); }
});

// ── INTERACTIONS ──
client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand() && !interaction.isButton() && !interaction.isStringSelectMenu() && !interaction.isModalSubmit()) return;
  try {

  // ── BUTTON HANDLERS ──
  if (interaction.isButton()) {
    
    // Open ticket → show category select menu
    if (interaction.customId === 'open_ticket') {
      const existing = interaction.guild.channels.cache.find(c => c.topic?.includes(`owner:${interaction.user.id}`));
      if (existing) return interaction.reply({ content: `❌ You already have an open ticket: ${existing}`, ephemeral: true });
      const tCats = [{"emoji":"💰","name":"Payment","desc":"Payment, billing or refund issues"},{"emoji":"🔧","name":"Technical Support","desc":"Bugs, errors or technical problems"},{"emoji":"👤","name":"Account","desc":"Account access, password or data"},{"emoji":"❓","name":"General Question","desc":"General questions about products or services"}];
      const selectRow = { type:1, components:[{ type:3, customId:'select_ticket_category', placeholder:'Select a category...', options: tCats.map(c=>({ label:`${c.emoji||''} ${c.name}`.trim(), value:c.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').slice(0,100), description:(c.desc||'').slice(0,100) })) }] };
      return interaction.reply({ embeds:[embed({ title:'🎫 Open Ticket', desc:'Select the category that best describes your issue.' })], components:[selectRow], ephemeral:true });
    }
    // Close ticket → ask confirmation
    if (interaction.customId === 'close_ticket') {
      if (!interaction.channel.topic?.includes('owner:') && !interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({ content: '❌ This is not a ticket channel.', ephemeral: true });
      }
      const confirmRow = { type:1, components:[
        { type:2, style:4, label:'✅ Confirm', customId:'confirm_close' },
        { type:2, style:2, label:'❌ Cancel', customId:'cancel_close' }
      ]};
      return interaction.reply({ content: '⚠️ Are you sure you want to close this ticket?', components:[confirmRow], ephemeral:true });
    }
    // Confirm close
    if (interaction.customId === 'confirm_close') {
      await interaction.reply({ content: '🔒 Closing ticket in 5 seconds...' });
      
      setTimeout(() => interaction.channel.delete().catch(()=>{}), 5000);
      return;
    }
    // Cancel close
    if (interaction.customId === 'cancel_close') {
      return interaction.reply({ content: '✅ Cancelled — ticket stays open.', ephemeral: true });
    }
    
    return;
  }

  // ── SELECT MENU HANDLERS ──
  if (interaction.isStringSelectMenu()) {
    
    if (interaction.customId === 'select_ticket_category') {
      const catValue = interaction.values[0];
      const tCats = [{"emoji":"💰","name":"Payment","desc":"Payment, billing or refund issues"},{"emoji":"🔧","name":"Technical Support","desc":"Bugs, errors or technical problems"},{"emoji":"👤","name":"Account","desc":"Account access, password or data"},{"emoji":"❓","name":"General Question","desc":"General questions about products or services"}];
      const catObj = tCats.find(c=>c.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').slice(0,100)===catValue)||{ name:catValue, emoji:'🎫' };
      const catLabel = `${catObj.emoji||''} ${catObj.name}`.trim();
      const existing = interaction.guild.channels.cache.find(c => c.topic?.includes(`owner:${interaction.user.id}`));
      if (existing) return interaction.reply({ content: `❌ You already have an open ticket: ${existing}`, ephemeral:true });
      const modal = new ModalBuilder().setCustomId(`ticket_modal_${catValue}`).setTitle('🎫 Open Ticket');
      const issueInput = new TextInputBuilder().setCustomId('ticket_issue').setLabel('Descreva seu problema').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1000).setPlaceholder('Descreva em detalhes...');
      modal.addComponents(new ActionRowBuilder().addComponents(issueInput));
      return interaction.showModal(modal);
    }
    
    return;
  }

  // ── MODAL SUBMIT HANDLERS ──
  if (interaction.isModalSubmit()) {
    
    if (interaction.customId.startsWith('ticket_modal_')) {
      const catValue = interaction.customId.replace('ticket_modal_','');
      const tCats = [{"emoji":"💰","name":"Payment","desc":"Payment, billing or refund issues"},{"emoji":"🔧","name":"Technical Support","desc":"Bugs, errors or technical problems"},{"emoji":"👤","name":"Account","desc":"Account access, password or data"},{"emoji":"❓","name":"General Question","desc":"General questions about products or services"}];
      const catObj = tCats.find(c=>c.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').slice(0,100)===catValue)||{ name:catValue, emoji:'🎫' };
      const catLabel = `${catObj.emoji||''} ${catObj.name}`.trim();
      const issueDesc = interaction.fields.getTextInputValue('ticket_issue');
      const imageUrl = '';
      await interaction.deferReply({ ephemeral:true });
      const guild = interaction.guild;
      let ticketCat = guild.channels.cache.find(c=>c.name==='Tickets' && c.type===4);
      if (!ticketCat) ticketCat = await guild.channels.create({ name:'Tickets', type:4 }).catch(()=>null);
      const chName = `ticket-${String(ticketCount).padStart(4,'0')}`;
      ticketCount++;
      const overwrites = [
        { id:guild.id, deny:[PermissionFlagsBits.ViewChannel] },
        { id:interaction.user.id, allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory,PermissionFlagsBits.AttachFiles] },
        { id:guild.members.me.id, allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ManageChannels,PermissionFlagsBits.ReadMessageHistory] }
      ];
      
      const ch = await guild.channels.create({ name:chName, type:0, parent:ticketCat?.id||null, permissionOverwrites:overwrites });
      await ch.setTopic(`owner:${interaction.user.id} | ticket:#${ticketCount-1}`).catch(()=>{});
      const closeRow = { type:1, components:[{ type:2, style:4, label:'Close Ticket', customId:'close_ticket' }] };
      
      const ticketEmbed = embed({ title:"🎫 Support Center", desc:replace("Thanks for opening a ticket! Our team will be with you shortly. 💬",interaction.member)+`\n\n**Categoria:** ${catLabel}\n> ${issueDesc}` });
      if(imageUrl) ticketEmbed.setImage(imageUrl);
      await ch.send({
        content:`<@${interaction.user.id}>`,
        embeds:[ticketEmbed],
        components:[closeRow]
      });
      
      return interaction.editReply({ content:`✅ Ticket criado: ${ch}` });
    }
    
    return;
  }

  const cmd = interaction.commandName;
  const guild = interaction.guild;

  // ── CUSTOM COMMANDS ──
  

  
  // ── INFO COMMANDS ──
  if (cmd === 'ping') return interaction.reply({ content: `🏓 Pong! \`${client.ws.ping}ms\``, ephemeral: true });

  if (cmd === 'serverinfo') {
    const e = embed({ title: guild.name })
      .setThumbnail(guild.iconURL())
      .addFields(
        { name: '👥 Members', value: String(guild.memberCount), inline: true },
        { name: '📢 Channels', value: String(guild.channels.cache.size), inline: true },
        { name: '🎭 Roles', value: String(guild.roles.cache.size), inline: true },
        { name: '👑 Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: '📅 Created', value: `<t:${Math.floor(guild.createdTimestamp/1000)}:D>`, inline: true }
      );
    return interaction.reply({ embeds: [e] });
  }

  if (cmd === 'userinfo') {
    const target = interaction.options.getUser('user') || interaction.user;
    const member = await guild.members.fetch(target.id).catch(()=>null);
    const e = embed({ title: target.username })
      .setThumbnail(target.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: '🆔 ID', value: target.id, inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(target.createdTimestamp/1000)}:D>`, inline: true },
        { name: '📥 Joined Server', value: member ? `<t:${Math.floor(member.joinedTimestamp/1000)}:D>` : 'N/A', inline: true }
      );
    return interaction.reply({ embeds: [e] });
  }

  if (cmd === 'avatar') {
    const target = interaction.options.getUser('user') || interaction.user;
    return interaction.reply({ embeds: [embed({ title: `${target.username}'s Avatar` }).setImage(target.displayAvatarURL({ size: 512 }))] });
  }

  
  // ── MODERATION ──
  if (cmd === 'ban') {
    if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) return interaction.reply({ content: '❌ No permission.', ephemeral: true });
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await guild.members.fetch(target.id).catch(()=>null);
    if (!member) return interaction.reply({ content: '❌ Member not found.', ephemeral: true });
    await target.send(`🔨 You were **banned** from **${guild.name}**. Reason: ${reason}`).catch(()=>{});
    await member.ban({ reason }).catch(()=>{});
    const logCh = await findChannel(guild, 'mod-logs');
    if (logCh) logCh.send({ embeds: [embed({ title: '🔨 Member Banned', desc: `**User:** ${target.username}\n**Moderator:** ${interaction.user.username}\n**Reason:** ${reason}` })] });
    return interaction.reply({ embeds: [embed({ title: '🔨 Banned', desc: `**${target.username}** has been banned. Reason: ${reason}` })] });
  }

  if (cmd === 'kick') {
    if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) return interaction.reply({ content: '❌ No permission.', ephemeral: true });
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await guild.members.fetch(target.id).catch(()=>null);
    if (!member) return interaction.reply({ content: '❌ Member not found.', ephemeral: true });
    await target.send(`👢 You were **kicked** from **${guild.name}**. Reason: ${reason}`).catch(()=>{});
    await member.kick(reason).catch(()=>{});
    const logCh = await findChannel(guild, 'mod-logs');
    if (logCh) logCh.send({ embeds: [embed({ title: '👢 Member Kicked', desc: `**User:** ${target.username}\n**Moderator:** ${interaction.user.username}\n**Reason:** ${reason}` })] });
    return interaction.reply({ embeds: [embed({ title: '👢 Kicked', desc: `**${target.username}** has been kicked. Reason: ${reason}` })] });
  }

  if (cmd === 'mute') {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ content: '❌ No permission.', ephemeral: true });
    const target = interaction.options.getUser('user');
    const mins = interaction.options.getInteger('minutes') || 10;
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await guild.members.fetch(target.id).catch(()=>null);
    if (!member) return interaction.reply({ content: '❌ Member not found.', ephemeral: true });
    await member.timeout(mins * 60000, reason).catch(()=>{});
    await target.send(`🔇 You were **muted** in **${guild.name}** for ${mins} minutes. Reason: ${reason}`).catch(()=>{});
    return interaction.reply({ embeds: [embed({ title: '🔇 Muted', desc: `**${target.username}** muted for ${mins} minutes. Reason: ${reason}` })] });
  }

  if (cmd === 'warn') {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ content: '❌ No permission.', ephemeral: true });
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    const key = guild.id+':'+target.id;
    const warns = warnings.get(key) || [];
    warns.push({ reason, by: interaction.user.username, at: new Date().toISOString() });
    warnings.set(key, warns);
    await target.send(`⚠️ You received a **warning** in **${guild.name}**. Reason: ${reason}. Total warnings: ${warns.length}`).catch(()=>{});
    const logCh = await findChannel(guild, 'mod-logs');
    if (logCh) logCh.send({ embeds: [embed({ title: '⚠️ Member Warned', desc: `**User:** ${target.username}\n**Moderator:** ${interaction.user.username}\n**Reason:** ${reason}\n**Total Warns:** ${warns.length}` })] });
    if (warns.length >= 3) {
      const member = await guild.members.fetch(target.id).catch(()=>null);
      if (member) { await member.kick('Exceeded warn limit').catch(()=>{}); return interaction.reply({ content: `⚠️ ${target.username} warned and auto-kicked (reached ${warns.length} warnings).` }); }
    }
    return interaction.reply({ embeds: [embed({ title: '⚠️ Warning Issued', desc: `**${target.username}** warned. Total: **${warns.length}/3**. Reason: ${reason}` })] });
  }

  if (cmd === 'warnings') {
    const target = interaction.options.getUser('user');
    const key = guild.id+':'+target.id;
    const warns = warnings.get(key) || [];
    const desc = warns.length ? warns.map((w,i)=>`**${i+1}.** ${w.reason} — by ${w.by}`).join('\n') : 'No warnings.';
    return interaction.reply({ embeds: [embed({ title: `⚠️ Warnings for ${target.username}`, desc })] });
  }

  if (cmd === 'clearwarn') {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ content: '❌ No permission.', ephemeral: true });
    const target = interaction.options.getUser('user');
    warnings.delete(guild.id+':'+target.id);
    return interaction.reply({ content: `✅ Cleared all warnings for **${target.username}**.` });
  }

  if (cmd === 'purge') {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) return interaction.reply({ content: '❌ No permission.', ephemeral: true });
    const amount = Math.min(interaction.options.getInteger('amount'), 100);
    await interaction.channel.bulkDelete(amount, true).catch(()=>{});
    return interaction.reply({ content: `🗑️ Deleted **${amount}** messages.`, ephemeral: true });
  }

  
  if (cmd === 'poll') {
    const q = interaction.options.getString('question');
    const msg = await interaction.reply({ embeds: [embed({ title: '📊 '+q })], fetchReply: true });
    await msg.react('👍');
    await msg.react('👎');
    setTimeout(async () => {
      const fetched = await msg.fetch();
      const yes = fetched.reactions.cache.get('👍')?.count-1||0;
      const no = fetched.reactions.cache.get('👎')?.count-1||0;
      msg.reply({ embeds: [embed({ title: '📊 Poll Results: '+q, desc: `👍 **${yes}** vs 👎 **${no}**\n\n${yes>no?'✅ Yes wins!':no>yes?'❌ No wins!':'🤝 It\'s a tie!'}` })] });
    }, 1800000);
  }

  
  if (cmd === 'tickets') {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({ content: "❌ You need 'Manage Channels' permission to post the ticket panel.", ephemeral: true });
    }
    let targetCh = interaction.channel;
    
    const openRow = { type:1, components:[{ type:2, style:1, label:'🎫 Open Ticket', customId:'open_ticket' }] };
    await targetCh.send({ embeds:[embed({ title:"🎫 Support Center", desc:"Need help? Click the button below to open a ticket.\n\nYou will choose the **category** of your problem and our team will assist you shortly." })], components:[openRow] });
    return interaction.reply({ content:`✅ Ticket panel posted in ${targetCh}!`, ephemeral:true });
  }


  
  if (cmd === 'giveaway') {
    const sub = interaction.options.getSubcommand();
    if (sub === 'start') {
      const prize = interaction.options.getString('prize');
      const mins = interaction.options.getInteger('minutes') || 60;
      const ends = new Date(Date.now() + mins * 60000);
      const emoji = '🎉';
      const msg = await interaction.reply({
        embeds: [embed({ title: `🎉 GIVEAWAY`, desc: `**Prize:** ${prize}\n**React with ${emoji} to enter!**\n**Ends:** <t:${Math.floor(ends/1000)}:R>\n**Hosted by:** ${interaction.user}` })],
        fetchReply: true
      });
      await msg.react(emoji);
      setTimeout(async () => {
        const fetched = await msg.fetch();
        const reaction = fetched.reactions.cache.get(emoji);
        if (!reaction) return msg.reply('No entries for the giveaway!');
        const users = (await reaction.users.fetch()).filter(u => !u.bot);
        if (!users.size) return msg.reply('No valid entries!');
        const winner = users.random();
        if (!winner) return msg.reply('Could not pick a winner.');
        const winMsg = '🎊 {winner} won **{prize}**!';
        msg.reply(winMsg.replace('{winner}',`<@${winner.id}>`).replace('{prize}',prize));
      }, mins * 60000);
    }
  }
  } catch(err) {
    console.error('\u274C Interaction error:', err);
    try {
      if (interaction.deferred) {
        await interaction.editReply({ content: '\u274C Ocorreu um erro interno. Tente novamente.', ephemeral: true });
      } else if (!interaction.replied) {
        await interaction.reply({ content: '\u274C Ocorreu um erro interno. Tente novamente.', ephemeral: true });
      }
    } catch(e) {}
  }
});

// ── MESSAGE EVENTS ──
client.on(Events.MessageCreate, async msg => {
  if (msg.author.bot || !msg.guild) return;

  
  // AutoMod
  const BANNED_WORDS = ''.split(',').map(w=>w.trim().toLowerCase()).filter(Boolean);
  const msgContent = msg.content.toLowerCase();
  let violated = BANNED_WORDS.length && BANNED_WORDS.some(w=>msgContent.includes(w));
  
  
  if (violated) {
    await msg.delete().catch(()=>{});
    const warnMsg = '⚠️ {user}, that word is not allowed!'.replace('{user}',`<@${msg.author.id}>`);
    const action = 'warn';
    const warning = await msg.channel.send(warnMsg);
    setTimeout(()=>warning.delete().catch(()=>{}), 5000);
    if (action === 'timeout') await msg.member.timeout(5*60000, 'AutoMod').catch(()=>{});
    else if (action === 'kick') await msg.member.kick('AutoMod').catch(()=>{});
    else if (action === 'ban') await msg.member.ban({ reason: 'AutoMod' }).catch(()=>{});
    
    return;
  }
});

// ── MEMBER JOIN ──
client.on(Events.GuildMemberAdd, async member => {
  
  // Welcome
  const welcomeMsg = replace('Welcome {user} to **{server}**! 👋 You are member #{membercount}.', member);
  const wCh = await findChannel(member.guild, 'general');
  if (wCh) {
    wCh.send(welcomeMsg);
  }
  
  // Auto Role
  const role = await findRole(member.guild, 'Member');
  if (role && !member.user.bot) await member.roles.add(role).catch(()=>{});
  
  if (true) {
    const logCh = await findChannel(member.guild, 'logs');
    if (logCh) logCh.send({ embeds: [embed({ title: '✅ Member Joined', desc: `<@${member.id}> | ${member.user.username}\nAccount created: <t:${Math.floor(member.user.createdTimestamp/1000)}:R>` }).setThumbnail(member.user.displayAvatarURL())] });
  }
});

// ── MEMBER LEAVE ──
client.on(Events.GuildMemberRemove, async member => {
  
  const goodbyeMsg = replace('Goodbye {user}! We will miss you. 😢', member);
  const gbCh = await findChannel(member.guild, 'general');
  if (gbCh) {
    gbCh.send(goodbyeMsg);
  }
  
  if (true) {
    const logCh = await findChannel(member.guild, 'logs');
    if (logCh) logCh.send({ embeds: [embed({ title: '❌ Member Left', desc: `${member.user.username}\nJoined: ${member.joinedAt?'<t:'+Math.floor(member.joinedTimestamp/1000)+':R>':'Unknown'}` }).setThumbnail(member.user.displayAvatarURL())] });
  }
});


// ── MESSAGE LOGS ──
client.on(Events.MessageUpdate, async (oldMsg, newMsg) => {
  if (!oldMsg.guild || oldMsg.author?.bot || oldMsg.content === newMsg.content) return;
  if (true) {
    const logCh = await findChannel(oldMsg.guild, 'logs');
    if (logCh) logCh.send({ embeds: [embed({ title: '✏️ Message Edited', desc: `**Author:** ${oldMsg.author?.username}\n**Channel:** ${oldMsg.channel}\n**Before:** ${oldMsg.content?.slice(0,500)||'N/A'}\n**After:** ${newMsg.content?.slice(0,500)||'N/A'}` })] });
  }
});

client.on(Events.MessageDelete, async msg => {
  if (!msg.guild || msg.partial || msg.author?.bot) return;
  if (true) {
    const logCh = await findChannel(msg.guild, 'logs');
    if (logCh) logCh.send({ embeds: [embed({ title: '🗑️ Message Deleted', desc: `**Author:** ${msg.author?.username}\n**Channel:** ${msg.channel}\n**Content:** ${msg.content?.slice(0,500)||'[Attachment/Unknown]'}` })] });
  }
});


// ── BAN LOGS ──
client.on(Events.GuildBanAdd, async ban => {
  const logCh = await findChannel(ban.guild, 'logs');
  if (logCh) logCh.send({ embeds: [embed({ title: '🔨 Member Banned', desc: `**User:** ${ban.user.username}\n**Reason:** ${ban.reason||'No reason provided'}` })] });
});
client.on(Events.GuildBanRemove, async ban => {
  const logCh = await findChannel(ban.guild, 'logs');
  if (logCh) logCh.send({ embeds: [embed({ title: '✅ Member Unbanned', desc: `**User:** ${ban.user.username}` })] });
});

client.login(TOKEN);
