# Render Setup

1. Create a **Background Worker** on [Render](https://render.com)
2. Connect your GitHub repo
3. Set **Build**: `npm install`, **Start**: `node index.js`
4. Add env vars: `TOKEN` and `CLIENT_ID`
